Include:
<?cs include:"list.cs" ?>