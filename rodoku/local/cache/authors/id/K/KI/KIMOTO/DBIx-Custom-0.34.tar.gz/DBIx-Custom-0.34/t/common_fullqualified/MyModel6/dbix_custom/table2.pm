package MyModel6::dbix_custom::table2;

use base 'MyModel6';

1;
