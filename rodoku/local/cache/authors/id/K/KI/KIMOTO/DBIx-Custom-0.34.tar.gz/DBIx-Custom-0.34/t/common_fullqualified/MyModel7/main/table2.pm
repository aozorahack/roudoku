package MyModel7::main::table2;

use base 'MyModel7';

1;
