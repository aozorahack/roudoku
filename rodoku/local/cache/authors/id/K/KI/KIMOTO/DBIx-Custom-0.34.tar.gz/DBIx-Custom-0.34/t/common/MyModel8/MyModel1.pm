package MyModel8::MyModel1;
use DBIx::Custom::Model -base;

1;
