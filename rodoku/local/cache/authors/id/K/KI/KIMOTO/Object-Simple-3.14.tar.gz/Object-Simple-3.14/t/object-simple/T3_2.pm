package T3_2;

use Some::T2 -base;

has z => 3;

1;
