package MyModel6;

use base 'DBIx::Custom::Model';

1;
