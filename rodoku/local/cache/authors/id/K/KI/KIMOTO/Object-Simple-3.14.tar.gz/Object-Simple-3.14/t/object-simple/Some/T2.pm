package Some::T2;

use Object::Simple -base;

has x => 1;
has y => 2;

1;
