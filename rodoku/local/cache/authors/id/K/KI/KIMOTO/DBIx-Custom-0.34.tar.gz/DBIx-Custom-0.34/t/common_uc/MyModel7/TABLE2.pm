package MyModel7::TABLE2;

use base 'MyModel7';

1;
