package T3;

use Some::T2 -base;

has z => 3;

1;
