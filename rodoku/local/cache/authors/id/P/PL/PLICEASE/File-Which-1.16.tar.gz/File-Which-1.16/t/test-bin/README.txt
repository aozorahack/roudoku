The files included in this directory are only used for testing: they
should not be executed: especially the *.exe files which aren't really
compiled programs, only empty files with special filenames (as
File::Which only cares about special attributes). Do NOT try to run
them.
