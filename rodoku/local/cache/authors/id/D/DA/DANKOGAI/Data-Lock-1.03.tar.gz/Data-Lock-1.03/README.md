[![build status](https://secure.travis-ci.org/dankogai/p5-data-lock.png)](http://travis-ci.org/dankogai/p5-data-lock)

Data-Lock

$Id: README.md,v 1.0 2013/04/03 06:49:25 dankogai Exp $

This distribution contains Data::Lock and Attribute::Constant.

INSTALLATION

To install this module, run the following commands:

	perl Makefile.PL
	make
	make test
	make install

SUPPORT AND DOCUMENTATION

After installing, you can find documentation for this module with the
perldoc command.

    perldoc Data::Lock

You can also look for information at:

    RT, CPAN's request tracker
        http://rt.cpan.org/NoAuth/Bugs.html?Dist=Data-Lock

    AnnoCPAN, Annotated CPAN documentation
        http://annocpan.org/dist/Data-Lock

    CPAN Ratings
        http://cpanratings.perl.org/d/Data-Lock

    Search CPAN
        http://search.cpan.org/dist/Data-Lock


COPYRIGHT AND LICENCE

Copyright (C) 2008-2013 Dan Kogai

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.
